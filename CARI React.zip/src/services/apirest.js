export const ApiCari = "https://cari.villasoftsolutions.com/project/public/api/cari/";
//export const ApiCari = "http://localhost:8000/api/cari/";